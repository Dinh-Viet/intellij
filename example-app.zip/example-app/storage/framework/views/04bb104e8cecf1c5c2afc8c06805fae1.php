<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
  
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
  
    <style type="text/css">
        i{
            font-size: 50px;
        }
    </style>
</head>
<body>
    <div id="app">
        <main class="container">
            <form action="<?php echo e(route('book')); ?>">
                <div class="form-group">
                    <label for="exampleInputEmail1">Book Name</label>
                    <input type="text" class="form-control"  placeholder="Enter Name" name="title"> 
                </div>
                <button type="submit" class="btn btn-primary mt-2">Submit</button>
            </form>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Authorid</th>
                    <th scope="col">Title</th>
                    <th scope="col">ISBN</th>
                    <th scope="col">Pub_year</th>
                    <th scope="col">Available</th>   
                  </tr>
                </thead>
                <tbody>
                 <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($book->id); ?></th>
                        <td><?php echo e($book->authorid); ?></td>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->ISBN); ?></td>
                        <td><?php echo e($book->pub_year); ?></td>
                        <td><?php echo e($book->available); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </tbody>
              </table>
        </main>
    </div>
</body>
</html><?php /**PATH E:\PHPWorkSpace\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>